create
    definer = user@`%` procedure sp_ins_mb_pl_processing(IN p_process_id int, IN p_user_id int,
                                                         IN p_processing_stage int, IN p_projected int, IN p_actual int,
                                                         IN p_comments text, OUT p_id int)
BEGIN
DECLARE alreadyInserted INT DEFAULT 0;
SELECT id into alreadyInserted from mb_pl_processing where process_id = p_process_id and user_id = p_user_id and processing_stage = P_processing_stage;
	IF alreadyInserted = 0 THEN 
	    INSERT INTO mb_pl_processing(
	        process_id,
	        user_id,
	        processing_stage,
	        projected,
	        actual,
	        comments
	    )VALUES(
    		p_process_id,
        	p_user_id,
       		p_processing_stage,
        	p_projected,
        	p_actual,
        	p_comments
	    );
	    SET p_id = LAST_INSERT_ID();
	ELSE
            SET P_id = alreadyInserted;
	END IF;
    END;

